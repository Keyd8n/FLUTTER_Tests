import 'package:flutter/material.dart'; // Імпорт основного пакету Flutter.

class AnswerButton extends StatelessWidget {
  // Створення віджета AnswerButton як StatelessWidget.
  const AnswerButton({
    // Конструктор віджета AnswerButton.
    
    super.key,
    required this.answerText, // Обов'язковий параметр: текст відповіді, що відображається на кнопці.
    required this.onTap, // Обов'язковий параметр: функція, яка викликається при натисканні на кнопку.
  });

  final String
      answerText; // Оголошення фінальної змінної для зберігання тексту відповіді.
  final void Function()
      onTap; // Оголошення фінальної функції, яка буде викликатися при натисканні.

  @override
Widget build(BuildContext context) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 8.0), // Додаємо вертикальний відступ.
    child: ElevatedButton(
      onPressed: onTap,
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(
          vertical: 10,
          horizontal: 100,
        ),
        backgroundColor: const Color.fromARGB(255, 255, 255, 255), // Встановлення кольору фону кнопки (чорний).
        foregroundColor: const Color.fromARGB(255, 0, 0, 0), // Встановлення кольору тексту кнопки (білий).
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(40),
        ),
      ),
      child: Text(
        answerText,
        textAlign: TextAlign.center,
      ),
    ),
  );
}
}

